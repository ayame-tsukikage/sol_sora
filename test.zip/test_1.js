var userRpc = "";
var comRpc = "";
var rpcResultScreen;
var resultString = "";

var divRpcImgUser;
var divRpcImgCom;

window.onload = function () {
    rpcResultScreen = document.getElementById("result_screen");
    divRpcImgUser = document.getElementById("rpc_user");
    divRpcImgCom = document.getElementById("rpc_com");
}

function si() {
    comRpc = Math.floor(Math.random() * 3 + 1);
    if (comRpc == 1) {
        comRpc = "가위";
    }
    if (comRpc == 2) {
        comRpc = "바위";
    }
    if (comRpc == 3) {
        comRpc = "보";
    }

    resultString = "유저 : 가위";
    resultString = resultString + "\n";
    resultString = resultString + "컴퓨터 : " + comRpc;
    resultString += "\n";

    switch(comRpc){
        case "가위":
            divRpcImgCom.innerHTML = "<img src='c_sc.png'>"
            break;
        case "바위":
            divRpcImgCom.innerHTML = "<img src='c_ro.png'>"
            break;
        case "보":
            divRpcImgCom.innerHTML = "<img src='c_pa.png'>"
            break;
    }

    var winDrawLose = "";
    switch (comRpc) {
        case "가위":
            winDrawLose = "무승부입니다.";
            break;
        case "바위":
            winDrawLose = "패배했습니다ㅠ";
            break;
        case "보":
            winDrawLose = "승리했습니다!";
            break;
    }

    resultString = resultString + "결과 : " + winDrawLose;
    rpcResultScreen.value = resultString;

    divRpcImgUser.innerHTML = "<img src='sc.png'>"
    switch(comRpc){
        case "가위":
            divRpcImgCom.innerHTML = "<img src='c_sc.png'>"
            break;
        case "바위":
            divRpcImgCom.innerHTML = "<img src='c_ro.png'>"
            break;
        case "보":
            divRpcImgCom.innerHTML = "<img src='c_pa.png'>"
            break;
    }
}

function ro() {
    comRpc = Math.floor(Math.random() * 3 + 1);
    if (comRpc == 1) {
        comRpc = "가위";
    }
    if (comRpc == 2) {
        comRpc = "바위";
    }
    if (comRpc == 3) {
        comRpc = "보";
    }

    resultString = "유저 : 바위";
    resultString = resultString + "\n";
    resultString = resultString + "컴퓨터 : " + comRpc;
    resultString += "\n";

    var winDrawLose = "";
    switch (comRpc) {
        case "가위":
            winDrawLose = "승리했습니다!";
            break;
        case "바위":
            winDrawLose = "무승부입니다.";
            break;
        case "보":
            winDrawLose = "패배했습니다ㅠ";
            break;
    }

    resultString = resultString + "결과 : " + winDrawLose;
    rpcResultScreen.value = resultString;
    
    divRpcImgUser.innerHTML = "<img src='ro.png'>"
    switch(comRpc){
        case "가위":
            divRpcImgCom.innerHTML = "<img src='c_sc.png'>"
            break;
        case "바위":
            divRpcImgCom.innerHTML = "<img src='c_ro.png'>"
            break;
        case "보":
            divRpcImgCom.innerHTML = "<img src='c_pa.png'>"
            break;
    }
}


function pa() {
    comRpc = Math.floor(Math.random() * 3 + 1);
    if (comRpc == 1) {
        comRpc = "가위";
    }
    if (comRpc == 2) {
        comRpc = "바위";
    }
    if (comRpc == 3) {
        comRpc = "보";
    }

    resultString = "유저 : 보";
    resultString = resultString + "\n";
    resultString = resultString + "컴퓨터 : " + comRpc;
    resultString += "\n";

    var winDrawLose = "";
    switch (comRpc) {
        case "가위":
            winDrawLose = "패배했습니다ㅠ";
            break;
        case "바위":
            winDrawLose = "승리했습니다!";
            break;
        case "보":
            winDrawLose = "무승부입니다.";
            break;
    }

    resultString = resultString + "결과 : " + winDrawLose;
    rpcResultScreen.value = resultString;
    
    divRpcImgUser.innerHTML = "<img src='pa.png'>"
    switch(comRpc){
        case "가위":
            divRpcImgCom.innerHTML = "<img src='c_sc.png'>"
            break;
        case "바위":
            divRpcImgCom.innerHTML = "<img src='c_ro.png'>"
            break;
        case "보":
            divRpcImgCom.innerHTML = "<img src='c_pa.png'>"
            break;
    }
}