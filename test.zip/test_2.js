function dw(str){
    document.write(str);
}
function br(){
    document.write("<br>");
}